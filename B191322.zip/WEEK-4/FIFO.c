#include<stdio.h>


int main(){
	int n,frm,pf=0,hits=0,firstIndex=0;
	printf("enter size of reference string: ");
	scanf("%d",&n);
	printf("enter no of frames: ");
	scanf("%d",&frm);
	
	int a[n],f[frm];
	printf("Enter reference values: ");
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	
	for(int i=0;i<frm;i++){
		f[i]=-1;
	}
	
	for(int i=0;i<n;i++){
		
		int fl=0;
		for(int j=0;j<frm;j++){
			if(f[j]==a[i]){
				hits+=1;
				printf("hit-%d\n",a[i]);
				fl=1;
				break;
			}
			else if(f[j]==-1){
				for(int i=0;i<frm;i++){
					printf("%d",f[i]);
				}
				printf("\n");
				
				f[j]=a[i];
				pf+=1;
				fl=1;
				break;
			}
		}
		if(fl==1)
			continue;
		else{
			for(int i=0;i<frm;i++){
				printf("%d",f[i]);
			}
			printf("\n");
			f[firstIndex]=a[i];
			pf+=1;
			firstIndex+=1;
			if(firstIndex==frm)
				firstIndex=0;
		}
		
	}
	
	
	
	printf("page faults: %d",pf);
	printf("\nHits: %d\n",hits);

	
}
