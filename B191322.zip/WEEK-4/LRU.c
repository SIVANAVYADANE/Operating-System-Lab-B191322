#include<stdio.h>
#include<limits.h>

int min(int arr[],int n){
	int mini=INT_MAX,ind=0;
	for(int i=0;i<n;i++){
		if(arr[i]<mini){
			mini=arr[i];
			ind=i;
		}
	}
	return ind;
}

void initi(int arr[],int n,int ini){
	for(int i=0;i<n;i++)
		arr[i]=ini;
}

int main(){
	int n,frm,pf=0,hits=0;
	printf("enter size of reference string: ");
	scanf("%d",&n);
	printf("enter no of frames: ");
	scanf("%d",&frm);
	
	int a[n],f[frm],fcheck[frm];
	printf("Enter reference values: ");
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	
	initi(f,frm,-1);
	
	for(int i=0;i<n;i++){
		int fl=0;
		for(int j=0;j<frm;j++){
			if(f[j]==a[i]){
				hits+=1;
				printf("hit-%d\n",a[i]);
				fl=1;
				break;
			}
			else if(f[j]==-1){
				
				f[j]=a[i];
				pf+=1;
				fl=1;
				
				for(int i=0;i<frm;i++){
					printf("%d",f[i]);
				}
				printf("\n");
				break;
			}
		}
		if(fl==1)
			continue;
		else{
			initi(fcheck,frm,0);
			
			for(int k=0;k<frm;k++){			
				for(int j=i-1;j>=0;j--){
					if(f[k]==a[j]){
						fcheck[k]=j;
						break;
					}
				}	
			}
			
			int index=min(fcheck,frm);
			f[index]=a[i];
			pf+=1;
	
			for(int k=0;k<frm;k++){
				printf("%d",f[k]);
				
			}
			printf("\n");
		}
	}
	
	printf("page faults: %d",pf);
	printf("\nHits: %d\n",hits);
}
