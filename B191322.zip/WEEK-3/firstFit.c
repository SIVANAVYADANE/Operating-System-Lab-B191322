#include<stdio.h>

int main(){
	int n,m;
	printf("no.of enter pocesses: ");
	scanf("%d",&n);
	printf("no.of memory blocks: ");
	scanf("%d",&m);
	
	int p[n],mem[m],memAlc[n];
	printf("enter processes sizes: ");
	for(int i=0;i<n;i++){
		scanf("%d",&p[i]);
		memAlc[i]=-1;
	}
	
	printf("enter memory blocks sizes: ");
	for(int i=0;i<m;i++){
		scanf("%d",&mem[i]);
	}
	
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			if(mem[j]>=p[i]){
				mem[j]=p[i];
				memAlc[i]=j;
				mem[j]=0;
				break;
			}
		}
	}
	
	for(int i=0;i<n;i++){
		if(memAlc[i]==-1){
			printf("\n%d-none",i+1);
		}
		else{
			printf("\n%d-%d",i+1,memAlc[i]+1);
		}
		
	}
	
	

}
